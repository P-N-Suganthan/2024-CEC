clc
clear

pro=28;
trial=25; %运行次数
num=2000;% 保留结果数目
SR=[];
score=[];
uscore1 = [];
uscore2 = [];

for i = 1:pro
    
filename=['E:\各文档\班旋旋\师爷技术报告\CEC2024\COPs\CL-SRDE\CL-SRDE_F', num2str(i),'_D30', '.txt' ];
    T1=load(filename);
        % T1 = T1(1:end-1,:);
        
 %% 约束小于1e-4的都设置为0
for z = 2:2:50
        z1 = T1(:,z);
        z1(z1<1e-4)=0;
        T1(:,z) = z1;
end
        %added code finish
    
    filename=['E:\各文档\班旋旋\师爷技术报告\CEC2024\COPs\UDE-III\UDEIII_', num2str(i),'_30.mat'];
    T2=load(filename, '-ASCII');   
    
    %% 约束小于1e-4的都设置为0
    for z = 2:2:50
        z2 = T2(:,z);
        z2(z2<1e-4)=0;
        T2(:,z) = z2;
    end

cf=trial*(trial+1)/2; %计算cf，这里的运行次数是25
    
    USCORE=[];
%     final=[T1(end,:),T2(end,:)];
    final=[T1(end,1:2:end),T2(end,1:2:end)];
    TGT_F=median(final);
       
    % rank=[];
    archive1=[];
    archive2=[];
    obj1=[];
    obj2=[];
    FE1=[];
    FE2=[];

    for k = 1:trial
        if T1(end,2*k)>0 %% 找不到可行解
            % FE1=num;
            % archive1=[archive1,min(T1(:,2*k))];%%保存约束
            archive1=[archive1,T1(end,2*k)];%%保存约束
%             obj1 = [obj1,T1(end,2*k-1)];%%保存目标值
        else %%找到可行解
%             if isempty((find(T1(:,2*k-1)<=TGT_F))) || T1(end,2*k-1) >TGT_F %% 大于中位值
            if T1(end,2*k-1) >TGT_F %% 大于中位值
                % FE1=num;
%                 archive1=[archive1,min(T1(:,2*k))];%%保存约束
                obj1 = [obj1,T1(end,2*k-1)];%%保存目标值
            else
                % FE1=[FE1 min((find(T1(:,2*k-1)<=TGT_F)))];
%                 [~,max_ind1] = max((find(T1(:,2*k-1)>TGT_F& T1(:,2*k)<=0)));
%                 FE1=[FE1, max((find(T1(:,2*k-1)>TGT_F& T1(:,2*k)<=0)))];
                panduan1 = find(T1(:,2*k-1)>TGT_F & T1(:,2*k)<=0);
                if isempty(panduan1)
                    FE1=[FE1, max((find(T1(:,2*k)>0)))+1];
                else
                    FE1=[FE1, max((find(T1(:,2*k-1)>TGT_F& T1(:,2*k)<=0)))];
                end
            end
        end

        if T2(end,2*k)>0
            % FE2=num;
            % archive2=[archive2,min(T2(:,2*k))];%%保存约束
            archive2=[archive2,T2(end,2*k)];%%保存约束
%             obj2 = [obj2,T2(end,2*k-1)];%%保存目标值
        else
%             if isempty((find(T2(:,2*k-1)<=TGT_F))) || T2(end,2*k-1) >TGT_F
            if T2(end,2*k-1) >TGT_F
                % FE2=num;
%                 archive2=[archive2,T2(end,2*k)];
                obj2 = [obj2,T2(end,2*k-1)];%%保存目标值
            else
                % FE2=[FE2 min((find(T2(:,2*k-1)<=TGT_F)))];
%                 [~, max_ind2] = max((find(T2(:,2*k-1)>TGT_F& T2(:,2*k)<=0)));
                panduan2 = find(T2(:,2*k-1)>TGT_F & T2(:,2*k)<=0);
                if isempty(panduan2)
                    FE2=[FE2, max((find(T2(:,2*k)>0)))+1];
                else
                    FE2=[FE2, max((find(T2(:,2*k-1)>TGT_F & T2(:,2*k)<=0)))];
                end
            end
        end

        % rank=[rank;FE1,FE2];

    end
    
    %% 首先排序找不到可行解的情况
    archive = [archive1 archive2];
    if ~isempty(archive)
        rank_con = length(archive)+1-tiedrank(archive);
    
        rank_con1 = rank_con(1:length(archive1));
        rank_con2 = rank_con(length(archive1)+1:end);
    else
        rank_con1 = [];
        rank_con2 = [];
    end
    %% 再排序找到可行解但是没有到达中位值的情况
    obj = [obj1 obj2];
    if ~isempty(obj)
        rank_obj = length(obj)+1-tiedrank(obj);
    
        rank_obj1 = rank_obj(1:length(obj1));
        rank_obj2 = rank_obj(length(obj1)+1:end);
        rank_obj1 = rank_obj1+length(archive);
        rank_obj2 = rank_obj2+length(archive);
    else
        rank_obj1 = [];
        rank_obj2 = [];
        
    end
    %% 最后排序低于中位值的情况
    % FES=[rank(:,1);rank(:,2)];
    % FES1 = rank(:,1);
    % FES2 = rank(:,2);
    FES = [FE1 FE2];
    if ~isempty(FES)
        rank_FES = length(FES)+1-tiedrank(FES);
    
        rank_FES1 = rank_FES(1:length(FE1));
        rank_FES2 = rank_FES(length(FE1)+1:end);
        rank_FES1 = rank_FES1+length(archive)+length(obj);
        rank_FES2 = rank_FES2+length(archive)+length(obj);
    else
        rank_FES1 = [];
        rank_FES2 = [];
    end
    %% 对以上三种情况汇总，得到每个算法的每次运行在此问题上的排名
    rank1 = sum(rank_con1) + sum(rank_obj1) + sum(rank_FES1) - cf;
    rank2 = sum(rank_con2) + sum(rank_obj2) + sum(rank_FES2) - cf;
   
  uscore1 = [uscore1 rank1];
  uscore2 = [uscore2 rank2];
end
U_score = [uscore1' uscore2']
sum(U_score)