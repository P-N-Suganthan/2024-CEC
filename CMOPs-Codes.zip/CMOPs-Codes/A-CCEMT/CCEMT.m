classdef CCEMT < ALGORITHM
% <multi> <real/integer/label/binary/permutation> <constrained>
% local auxiliary task-based constrained multiobjective optimization

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population{1} = Problem.Initialization(); % Main task
            Fitness{1}    = CalFitness(Population{1}.objs,Population{1}.cons);
            Fmin       = min(Population{1}.objs,[],1);
            Zmin       = min(Population{1}.objs,[],1);
            Population{2} = Problem.Initialization(); % Global auxiliary task
            Fitness{2}   = CalFitness(Population{2}.objs);
            Population{3} = Problem.Initialization(); % Local auxiliary task
            Fitness{3}   = CalFitness(Population{3}.objs,Population{3}.cons);

            % Calculate the constraint boundary of local auxiliary task
            cons = [Population{1}.cons;Population{2}.cons;Population{3}.cons];
            cons(cons<0) = 0;
            VAR0 = max(sum(cons,2));
            if VAR0 == 0
                VAR0 = 1;
            end
            X=0;

            % 参数
            cnt = 1; % index of generation
            PR0 = 0.1;
            Alpha = 0.5;
            Beta = 0.1;
            Pmin = 0.1;
            RH = 10;
            CHNum=3;
            % Initialize parameters of CCEF
            HR = 0 * ones(CHNum, RH); % History Record 历史奖励矩阵
            HRIdx = ones(1, CHNum);
            CHPro(cnt,:) = 1 / CHNum * ones(1, CHNum);%选择每个CHT的概率向量
            %% Optimization
            while Algorithm.NotTerminated(Population{1})
                cnt =cnt +1;
                %% Udate the epsilon value
                cp  = (-log(VAR0)-6)/log(1-0.5);
                VAR = VAR0*(1-X)^cp;
               %% Select a task to evolve
                if Problem.FE <= Beta * Problem.maxFE % Stage 1: Development
                    CHPro(cnt, :) = 1 / CHNum * ones(1, CHNum); %每个CHT选择概率相同
                else % Stage 2: Competition
                    if sum(HR, 'all') ~= 0
                        CHPro(cnt, :) = Pmin / CHNum + (1 - Pmin) * sum(HR, 2) ./ max(sum(HR, 'all'));
                        CHPro(cnt, :) = CHPro(cnt, :) ./ sum(CHPro(cnt, :)); %这一步操作是为了令所有的概率和为1
                    else
                        CHPro(cnt, :) = 1 / CHNum * ones(1, CHNum);
                    end
                end
                ch_k = RouletteWheelSelection(1,CHPro(cnt, :)); %采用轮盘赌选择一个CHT作为主CHT进化


                %% Parent Reconstruction
                MatingPool = TournamentSelection(2,Problem.N,Fitness{ch_k});
                parent = Population{ch_k}(MatingPool);
                HelpCH = 1:CHNum; HelpCH(HelpCH == ch_k) = [];
                for i = 1:length(parent)
                    if rand() < PR0
                        ch_help = HelpCH(randi(length(HelpCH)));
                        %随机选择一个解
                        temp=Population{ch_help}(randi(length(Population{ch_help})));
                        CV1=sum(max(temp.cons,0),2);
                        CV2=sum(max(parent(i).cons,0),2);
                        if (CV2 > CV1 || ...
                           (CV2 == CV1 && sum(parent(i).objs >= temp.objs)==Problem.M))
                            parent(i) = temp;
                        end
                    end
                end

                %% Offspring Generation
                MatingPool = [parent(randsample(Problem.N,Problem.N))];
                [Mate1,Mate2,Mate3] = Neighbor_Pairing_Strategy(MatingPool,Zmin);
                if rand > 0.5
                    Offspring = OperatorDE(Problem,Mate1,Mate2,Mate3);
                else
                    Offspring = OperatorDE(Problem,Mate1,Mate2,Mate3,{0.5,0.5,0.5,0.75});
                end
                % MatingPool = [parent(randsample(Problem.N,Problem.N))];
                % [Mate1,Mate2,Mate3]  = Neighbor_Pairing_Strategy(MatingPool,Zmin);
                % Offspring(1:Problem.N/2) = OperatorDE_rand_1(Problem,Mate1(1:Problem.N/2), Mate2(1:Problem.N/2), Mate3(1:Problem.N/2));
                % if  ch_k==1
                %     fitness=CalFitness(parent.objs,parent.cons);
                % elseif ch_k==2
                %     fitness=CalFitness(parent.objs);
                % else
                %     fitness=CalFitness([parent.objs,sum(max(parent.cons,0),2)]);
                % end
                % Offspring(1+Problem.N/2:Problem.N) = OperatorDE_pbest_1_main(parent, Problem.N/2, Problem, fitness, 0.1);

                % Offspring(1:Problem.N/2) = OperatorGAhalf(Problem,parent(randsample(Problem.N,Problem.N)));
                % Offspring(1+Problem.N/2 : Problem.N) = DE_current_to_rand_1(Problem, parent, Problem.N/2);
                old= Fmin;
                Fmin = min([Fmin;Offspring(all(Offspring.cons<=0,2)).objs],[],1);
                Zmin=min([Zmin;Offspring.objs],[],1);
                reward_global = any(Fmin<old); %全局奖励：对所有可行解最小值的改变

                %% Environmental selection
                [Population{1},succ{1},Fitness{1}] = EnvironmentalSelection([Population{1},Offspring],Problem.N,true);  
                [Population{2},succ{2},Fitness{2}] = EnvironmentalSelection([Population{2},Offspring],Problem.N,false);
                [Population{3},succ{3},Fitness{3}] = EnvironmentalSelection_LAT([Population{3},Offspring],Problem.N,VAR);
                reward_pop=succ{ch_k}; %种群收敛奖励:进入下一代的个数比例

                %% 更新奖励矩阵
                Rb = reward_global;
                Rp = reward_pop;
                HR(ch_k, HRIdx(ch_k)) = Alpha * Rb + (1 - Alpha) * mean(Rp);
                HRIdx(ch_k) = mod(HRIdx(ch_k), RH) + 1;

                %% Plot
                % if Problem.FE>=Problem.maxFE
                %     C = colorplus([441,424,284,361,272,56,189,109]);
                %     temp=40;
                %     x=[1,temp:temp:floor(cnt/temp)*temp,cnt]
                %     plot(x,CHPro(x,1),'Color',C(2,:),'LineStyle','-','LineWidth',1.5,'Marker','^') 
                %     hold on
                %     plot(x,CHPro(x,2),'Color',C(3,:),'LineStyle','-','LineWidth',1.5,'Marker','o') 
                %     hold on
                %     plot(x,CHPro(x,3),'Color','r','LineStyle','-','LineWidth',1.5,'Marker','square') 
                %     % plot(x,CHPro(1:5:cnt,1),x,CHPro(1:5:cnt,2),x,CHPro(1:5:cnt,3));
                %     % title('LIRCMOP4','FontSize',15,'Interpreter','latex')
                %     legend('$T_1$','$T_2$','$T_3$','Interpreter','latex')	
                %     set(gca,'FontName','Times New Roman','FontSize',15);
                %     xlabel('Generation','Times New Roman','FontSize',15)
                %     ylabel('Selection Probability','Times New Roman','FontSize',15)       
                % end
            end
        end
    end
end