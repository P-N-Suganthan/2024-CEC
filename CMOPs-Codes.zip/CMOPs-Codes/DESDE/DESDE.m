classdef DESDE < ALGORITHM
% <multi/many> <real/integer> <large><constrained>

%------------------------------- Reference --------------------------------
% X. Zhang, Y. Tian, R. Cheng, and Y. Jin, A decision variable clustering
% based evolutionary algorithm for large-scale many-objective optimization,
% IEEE Transactions on Evolutionary Computation, 2018, 22(1): 97-112.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)

            %% Generate random population
            Population1 = Problem.Initialization();
            % Population2 = Problem.Initialization();
          

            cons = Population1.cons;
            cons(cons <= 0)=0;
            conss = sum(cons,2);
            epsilon0 = max(conss);
            if epsilon0 == 0
                epsilon0 = 1;
            end
Fitness1    = CalFitness_E(Population1.objs,Population1.cons,epsilon0);
% Fitness2    = CalFitness_E(Population2.objs);

            %% Optimization
            while Algorithm.NotTerminated(Population1)
                 
                cp=(-log(epsilon0)-6)/log(1-0.5);
                % epsilon = epsilon0*(1-X)^cp;
                % if Problem.FE < 1/3*Problem.maxFE
                    epsilon = epsilon0*(1-Problem.FE/Problem.maxFE)^cp;
                   

                    Offspring1 = OperatorDE_pbest_1_main(Population1, Problem.N, Problem, Fitness1, 1-(0.99/Problem.maxFE)*Problem.FE);
                    % Offspring2 = OperatorDE_pbest_1_main(Population2, Problem.N, Problem, Fitness2, 1-(0.99/Problem.maxFE)*Problem.FE);
                    % Fitness_he    = CalFitness_E(Population.objs,Population.cons,epsilon);
                    % MatingPool = TournamentSelection(2,2*Problem.N,Fitness_he);
%                     Offspring  = OperatorGA(Problem,Population(MatingPool));
                    % Offspring  = OperatorDE(Problem,Population,Population(MatingPool(1:end/2)),Population(MatingPool(end/2+1:end)));

                    [Population1,Fitness1] = Improve_E_EnvironmentalSelection([Population1,Offspring1],Problem.N,epsilon);
                    % [Population2,Fitness2] = EnvironmentalSelection([Population1,Population2,Offspring1,Offspring2],Problem.N,0,true);
                    % [Population,Fitness] = EnvironmentalSelection([Population,Offspring],Problem.N,epsilon,true);
                    % [Population,Fitness] = EnvironmentalSelection_MultiE([Population,Offspring],Problem.N,epsilon,true);

             
            end
        end
    end
end

