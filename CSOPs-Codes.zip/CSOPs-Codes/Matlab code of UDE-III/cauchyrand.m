function rnd = cauchyrand(mu, c)

rnd = c.*tan(pi*(rand-0.5))+mu;

end

