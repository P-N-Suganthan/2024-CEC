# An Efficient Reconstructed Differential Evolution Variant by Some of the Current State-of-the-art Strategies for Solving Single Objective Bound Constrained Problems

This repo contains necessary code for the paper currently published on arXiv [An Efficient Reconstructed Differential Evolution Variant by Some of the Current State-of-the-art Strategies for Solving Single Objective Bound Constrained Problems] available at [arXiv: https://arxiv.org/abs/2404.16280].

The code is developed by Sichen Tao [Google Scholar: https://scholar.google.com.hk/citations?user=gmOx-i4AAAAJ&hl=ja], [ResearchGate: https://www.researchgate.net/profile/Sichen-Tao/research], [e-mail: taosc73@hotmail.com, terrysc777@gmail.com]. The code will also be available at [GitHub: https://github.com/terrysc and https://github.com/SichenTao].

Please run the code below in the terminal to build RDE.exe for running RDE:
g++ RDE.cpp -o RDE.exe -std=c++11 -O3 -march=corei7-avx -fexpensive-optimizations -fomit-frame-pointer

Please cite our paper and the technical report for the CEC2024 competition on numerical optimization as follows:

S. Tao, R. Zhao, K. Wang, and S. Gao, “An efficient reconstructed differential evolution variant by some of the current state-of-the-art strategies for solving single objective bound constrained problems,” arXiv preprint arXiv:2404.16280, 2024.

K. Qiao, X. Wen, X. Ban, P. Chen, K. V. Price, P. N. Suganthan, J. Liang, G. Wu, and C. Yue, “Evaluation criteria for cec 2024 competition and special session on numerical optimization considering accuracy and speed,” Zhengzhou University, Central South University, Henan Institute of Technology, Qatar University, Tech. Rep., 2024.

BIBTEX:
@article{tao2024efficient,
  title={An Efficient Reconstructed Differential Evolution Variant by Some of the Current State-of-the-art Strategies for Solving Single Objective Bound Constrained Problems},
  author={Tao, Sichen and Zhao, Ruihan and Wang, Kaiyu and Gao, Shangce},
  journal={arXiv preprint arXiv:2404.16280},
  year={2024}
}
