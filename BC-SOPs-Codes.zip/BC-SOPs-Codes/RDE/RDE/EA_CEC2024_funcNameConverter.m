%% Developed by Sichen Tao on June 27, 2024
%% Note: the 2nd function (F2) has been excluded in both CEC2017 and CEC2024.
clc
clear;
problemNum = 30;
dirName = 'NewData';
mkdir(dirName);
for problem_id = [1, 3:30]
    if problem_id == 1
        filename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        load(filename);
        data = convergence_results;
        newfilename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        save([dirName, '/', newfilename], 'data')
    elseif problem_id == 2 % Note: please delete the F2 before running this code
    else
        filename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        load(filename);
        data = convergence_results;
        newfilename = ['RDE_F', num2str(problem_id-1), '_Min_EV.mat'];
        save([dirName, '/', newfilename], 'data')
    end
end
