clc
clear

pro=10;
trial=30; %运行次数
num=500;% 保留结果数目
SR=[];
score=[];
for i = 1:pro
    filename=['E:\CEC2024result\TEMOFBCEIBEA\TEMOFBCEIBEA_MaOP', num2str(i), '.mat' ];
    
    T1=load(filename).output;
    
    filename=['E:\CEC2024result\TEMOFGFMMOEA\TEMOFGFMMOEA_MaOP', num2str(i), '.mat' ];
    T2=load(filename).output;
    
    
    filename=['E:\CEC2024result\TEMOFNSGA3\TEMOFNSGA3_MaOP', num2str(i), '.mat' ];
    T3=load(filename).output;
    

    
%     cf=trial*(trial+1)/2;   %计算cf，这里的运行次数是1000
    
    USCORE=[];
    final=[T1(end,:),T2(end,:),T3(end,:)];
    TGT=mean(final);
     cf=trial*(trial+1)/2;   %计算cf，这里的运行次数是1000
    rank=[];
    archive1=[];
    archive2=[];
    archive3=[];
    
    for k = 1:trial 
        if isempty((find(T1(:,k)<=TGT))) || T1(end-1,k) >TGT
            FE1=num;
            archive1=[archive1,T1(end,k)];
        else
            FE1=min((find(T1(:,k)<=TGT)));
        end
        
        if isempty((find(T2(:,k)<=TGT)))|| T2(end-1,k) >TGT
            FE2=num;
            archive2=[archive2,T2(end,k)];
        else
            FE2=min((find(T2(:,k)<=TGT)));
        end
        
        if isempty((find(T3(:,k)<=TGT)))|| T3(end-1,k) >TGT
            FE3=num;
            archive3=[archive3,T3(end,k)];
        else
            FE3=min((find(T3(:,k)<=TGT)));
        end
        
%         if isempty((find(T4(:,k)<=TGT)))|| T4(end-1,k) >TGT
%             FE4=num;
%             archive4=[archive4,T4(end,k)];
%         else
%             FE4=min((find(T4(:,k)<=TGT)));
%         end
        rank=[rank;FE1,FE2,FE3];

    end
    RANK=[rank(:,1);rank(:,2);rank(:,3)];
    [sorted_vector, indices] = sort(RANK);
    Rank = zeros(size(RANK));
    Rank(indices) = 1:numel(RANK);
    for i = 1:length(RANK)
        if RANK(i)==num
            Rank(i)=0;
        else
            Rank(i)=91-Rank(i);
        end
    end
    
    sr=[sum(Rank(1:trial)),sum(Rank(trial+1:2*trial)),sum(Rank(2*trial+1:3*trial))];
    peak= sum(Rank~=0);
    
    if length(archive1)<trial
        archive1=[archive1,Inf.*ones(1,trial-length(archive1))];
    end
    
    if length(archive2)<trial
        archive2=[archive2,Inf.*ones(1,trial-length(archive2))];
    end
    
    if length(archive3)<trial
        archive3=[archive3,Inf.*ones(1,trial-length(archive3))];
    end
    
%     if length(archive4)<trial
%         archive4=[archive4,Inf.*ones(1,trial-length(archive4))];
%     end
    ARCHIVE=[archive1,archive2,archive3];
    [sorted_vector, indices] = sort(ARCHIVE);
    arc = zeros(size(ARCHIVE));
    arc(indices) = 1:numel(ARCHIVE);

    
    arc=arc+peak;
    arc=91-arc;
    arc(arc<0)=0;
%     arc(arc>((length(find(RANK==num)))+peak))=0;
    arc=[sum(arc(1:trial)),sum(arc(trial+1:2*trial)),sum(arc(2*trial+1:3*trial))];
    sr=sr+arc;
    [sorted_vector, indices] = sort(sr);
    rank = zeros(size(sr));
    rank(indices) = 1:numel(sr);
    SR=[SR;rank];
    sr=sr-cf;
    score=[score;sr];
end
sum(SR)