clc
clear

pro=28;
trial=25; %运行次数
num=2000;% 保留结果数目
SR=[];
score=[];
for i = 1:pro
    filename=['F:\CL-SRDE_F', num2str(i),'_D30', '.txt' ];

%     save()
    
%     T1=load(filename).output;
        T1=load(filename);
        T1 = T1(1:end-1,:);
    
    filename=['F:\UDEIII_', num2str(i),'_30.mat'];
    T2=load(filename, '-ASCII');
    
    
cf=trial*(trial+1)/2; %计算cf，这里的运行次数是1000
    
    USCORE=[];
    final=[T1(end,:),T2(end,:)];
    TGT_F=mean(final);
       
    rank=[];
    archive1=[];
    archive2=[];

    for k = 1:trial
        if T1(end,2*k)>0
            FE1=num;
            archive1=[archive1,min(T1(:,2*k))];
        else
            if isempty((find(T1(:,2*k-1)<=TGT_F))) || T1(end-1,2*k-1) >TGT_F
                FE1=num;
                archive1=[archive1,T1(end,2*k-1)];
            else
                FE1=min((find(T1(:,2*k-1)<=TGT_F)));
            end
        end

        if T2(end,2*k)~=0
            FE1=num;
            archive2=[archive2,min(T2(:,2*k))];
        else
            if isempty((find(T2(:,2*k-1)<=TGT_F))) || T2(end-1,2*k-1) >TGT_F
                FE2=num;
                archive2=[archive2,T2(end,2*k-1)];
            else
                FE2=min((find(T2(:,2*k-1)<=TGT_F)));
            end
        end

        rank=[rank;FE1,FE2];

    end
    
    
    RANK=[rank(:,1);rank(:,2)];
    [sorted_vector, indices] = sort(RANK);
    Rank = zeros(size(RANK));
    Rank(indices) = 1:numel(RANK);
    for i = 1:length(RANK)
        if RANK(i)==num
            Rank(i)=0;
        else
            Rank(i)=101-Rank(i);
        end
    end
    
    sr=[sum(Rank(1:trial)),sum(Rank(trial+1:2*trial))];
    peak= sum(Rank~=0);
    
    if length(archive1)<trial
        archive1=[archive1,Inf.*ones(1,trial-length(archive1))];
    end
    
    if length(archive2)<trial
        archive2=[archive2,Inf.*ones(1,trial-length(archive2))];
    end
    
    
    ARCHIVE=[archive1,archive2];
    [sorted_vector, indices] = sort(ARCHIVE);
    arc = zeros(size(ARCHIVE));
    arc(indices) = 1:numel(ARCHIVE);

    arc=arc+peak;
    arc=101-arc;
    arc(arc<0)=0;
    
    arc=[sum(arc(1:trial)),sum(arc(trial+1:2*trial))];
    sr=sr+arc;
    [sorted_vector, indices] = sort(sr);
    rank = zeros(size(sr));
    rank(indices) = 1:numel(sr);
    SR=[SR;rank];
    sr=sr-cf;
    score=[score;sr];
end
sum(SR)