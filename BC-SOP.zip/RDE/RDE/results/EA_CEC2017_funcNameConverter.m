%% Developed by Sichen Tao on June 27, 2024
%% Note: please delete the function 2 (F2) result file before running this code, 
%% for the function 2 (F2) has been removed both in CEC2017 and CEC2024.
clc
clear;
problemNum = 30;
dirName = 'NewData';
mkdir(dirName);
for problem_id = [1, 3:30]
    if problem_id == 1
        filename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        load(filename);
        data = new_data;
        newfilename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        save([dirName, '/', newfilename], 'data')
    elseif problem_id == 2 % Note: please delete the F2 before running this code
    else
        filename = ['RDE_F', num2str(problem_id), '_Min_EV.mat'];
        load(filename);
        data = new_data;
        newfilename = ['RDE_F', num2str(problem_id-1), '_Min_EV.mat'];
        save([dirName, '/', newfilename], 'data')
    end
end
