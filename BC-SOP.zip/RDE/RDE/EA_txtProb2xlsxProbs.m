clc
clear
algName2write = 'RDE';
rawDataName2read = 'RDE';
benchmark = 'CEC2024';
dim_list = [30];
problem_list = [1:30];
problemNum = length(problem_list);
runtime = 25;

for dim = dim_list
    path2write = [algName2write, '_', benchmark, '_D', num2str(dim), '.xlsx'];
    for problem = problem_list(1:problemNum)
        disp(['Problem ', num2str(problem)]);
        txtfileName2read = [rawDataName2read, '_', benchmark, '_D', num2str(dim),'_F',num2str(problem),'.txt'];
        txtData2read = load(txtfileName2read);
%         txtData2read_reshaped = reshape(txtData2read, dim * 100, runtime);%999,2996,4994,9989   ADGHI_jr025_FO095
        txtData2read_reshaped = txtData2read;
        writematrix(txtData2read_reshaped, path2write, 'sheet', problem);
        matpath2write = [algName2write, '_F', num2str(problem), '_Min_EV.mat'];
        convergence_results = txtData2read_reshaped;
        save(matpath2write, 'convergence_results')
        txtData2read = [];
        txtData2read_reshaped =[];
    end
end
